# Optifine Requirement :
- OptiFine 1.15.2_HD_U_G1_pre21 : [Download](https://optifine.net/adloadx?f=preview_OptiFine_1.15.2_HD_U_G1_pre21.jar)
- Optifine website : [Here](https://optifine.net/home)
- Docs about CEM : [GitHub](https://github.com/sp614x/optifine/blob/master/OptiFineDoc/doc/cem_model.txt)